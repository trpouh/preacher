# The Preacher

This project serves two functions:

* Teach me Rust
* Provide a lightweight alternative to ansible(-pull) that can easily run on embedded devices

## Getting Started

### Windows

Sorry but no.

### MacOS



```

wget https://github.com/trpouh/preacher/releases/download/0.0.1/preacher_0.0.1_x86_64-apple-darwin.zip


```

### Linux

## Introduction

The architecture of the preacher is best described in this picture.

<p align="center">
  <img src="https://github.com/trpouh/preacher/blob/docs/docs/arch.svg?raw=true" alt="Preachers architecture"/>
</p>
